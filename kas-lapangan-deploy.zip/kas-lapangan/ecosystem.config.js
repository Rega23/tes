module.exports = {
  apps: [
    {
      name: 'kas-lapangan',
      cwd: __dirname + '/server',
      script: 'index.js',
      env: {
        NODE_ENV: 'production',
        PORT: 3001,
      },
    },
  ],
};
