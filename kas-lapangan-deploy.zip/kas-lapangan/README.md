# Buku Kas Lapangan — Panduan Deploy ke VPS

Aplikasi ini terdiri dari 2 bagian:
- `server/` — backend Node.js (Express) + database SQLite (file lokal, tidak perlu install database server terpisah)
- `client/` — frontend React (Vite), di-build jadi file statis lalu diserve oleh `server/`

Setelah build, server yang sama menyajikan API **dan** halaman web. Jadi cukup 1 proses Node.js yang jalan di VPS.

---

## 1. Prasyarat di VPS (Ubuntu/Debian)

```bash
# Update sistem
sudo apt update && sudo apt upgrade -y

# Install Node.js LTS (pakai nvm supaya gampang ganti versi)
curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash
source ~/.bashrc
nvm install --lts

# Install PM2 (menjaga aplikasi tetap jalan & auto-restart)
npm install -g pm2

# Install Nginx (reverse proxy + biar bisa pakai domain & SSL)
sudo apt install -y nginx
```

`better-sqlite3` di `server/` butuh build tools untuk compile native module:
```bash
sudo apt install -y build-essential python3
```

---

## 2. Upload project ke VPS

Paling gampang pakai `scp` dari komputer kamu (ganti `user@ip-vps` dan path sesuai punya kamu):

```bash
scp -r kas-lapangan user@ip-vps:/var/www/kas-lapangan
```

Atau kalau kamu simpan project ini di Git, `git clone` langsung di VPS ke `/var/www/kas-lapangan`.

---

## 3. Install dependencies & build

```bash
cd /var/www/kas-lapangan

# Backend
cd server
npm install
cd ..

# Frontend — build jadi file statis di client/dist
cd client
npm install
npm run build
cd ..
```

Setelah ini, folder `client/dist` sudah berisi file HTML/JS/CSS hasil build, dan `server/index.js` sudah dikonfigurasi untuk menyajikannya otomatis.

---

## 4. Jalankan dengan PM2

```bash
cd /var/www/kas-lapangan
pm2 start ecosystem.config.js
pm2 save
pm2 startup   # ikuti instruksi yang muncul, supaya PM2 auto-start saat VPS reboot
```

Cek statusnya:
```bash
pm2 status
pm2 logs kas-lapangan
```

Server berjalan di `http://localhost:3001` di dalam VPS. Langkah berikutnya menghubungkan ini ke domain kamu lewat Nginx.

---

## 5. Setup Nginx (reverse proxy + domain)

Buat file config baru:
```bash
sudo nano /etc/nginx/sites-available/kas-lapangan
```

Isi dengan (ganti `domainkamu.com`):
```nginx
server {
    listen 80;
    server_name domainkamu.com;

    location / {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
```

Aktifkan dan reload:
```bash
sudo ln -s /etc/nginx/sites-available/kas-lapangan /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

Pastikan DNS domain kamu (A record) sudah diarahkan ke IP VPS ini.

---

## 6. Aktifkan HTTPS (SSL gratis via Let's Encrypt)

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d domainkamu.com
```

Certbot akan otomatis mengubah config Nginx untuk redirect ke HTTPS dan mengatur perpanjangan sertifikat otomatis.

Sekarang aplikasi bisa diakses lewat `https://domainkamu.com`.

---

## 7. Update aplikasi di kemudian hari

```bash
cd /var/www/kas-lapangan
# upload/pull perubahan file dulu, lalu:
cd client && npm run build && cd ..
pm2 restart kas-lapangan
```

---

## 8. Backup data

Semua data (transaksi & kategori) tersimpan di satu file:
```
server/data.db
```
Backup rutin cukup dengan menyalin file ini (mis. lewat cron + `scp`/`rclone` ke tempat lain). Contoh cron harian jam 1 malam:
```bash
crontab -e
# tambahkan baris:
0 1 * * * cp /var/www/kas-lapangan/server/data.db /var/backups/kas-lapangan-$(date +\%F).db
```

---

## Catatan keamanan

Aplikasi ini **belum punya login/password** — siapa pun yang tahu URL-nya bisa mengisi & mengubah data. Karena ini dipakai bareng tim internal, beberapa opsi kalau perlu dibatasi:
- Password sederhana di level Nginx (`auth_basic`) — cukup untuk internal team, mudah disetel.
- Batasi akses ke IP kantor/tim tertentu lewat firewall (`ufw allow from <ip>`).
- Kalau butuh login per-user dengan role berbeda, itu perlu ditambahkan di level aplikasi (bisa dibantu dikembangkan lebih lanjut kalau diperlukan).
