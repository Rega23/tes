const express = require('express');
const path = require('path');
const crypto = require('crypto');
const Database = require('better-sqlite3');

const app = express();
const PORT = process.env.PORT || 3001;
const db = new Database(path.join(__dirname, 'data.db'));

db.pragma('journal_mode = WAL');

db.exec(`
  CREATE TABLE IF NOT EXISTS entries (
    id TEXT PRIMARY KEY,
    tanggal TEXT NOT NULL,
    penyetor TEXT NOT NULL,
    namaAccount TEXT NOT NULL,
    jumlah REAL NOT NULL,
    keterangan TEXT,
    createdAt INTEGER NOT NULL
  );
  CREATE TABLE IF NOT EXISTS categories (
    name TEXT PRIMARY KEY
  );
`);

const DEFAULT_CATEGORIES = ['TOL', 'PARKIR', 'PARKIR LIAR', 'BONGKAR MUAT'];
const existingCatCount = db.prepare('SELECT COUNT(*) AS c FROM categories').get().c;
if (existingCatCount === 0) {
  const insertCat = db.prepare('INSERT INTO categories (name) VALUES (?)');
  const insertMany = db.transaction((names) => { names.forEach((n) => insertCat.run(n)); });
  insertMany(DEFAULT_CATEGORIES);
}

app.use(express.json());

// ---- Entries ----
app.get('/api/entries', (req, res) => {
  const rows = db.prepare('SELECT * FROM entries ORDER BY tanggal ASC, createdAt ASC').all();
  res.json(rows);
});

app.post('/api/entries', (req, res) => {
  const { tanggal, penyetor, namaAccount, jumlah, keterangan } = req.body || {};
  if (!tanggal || !penyetor || !namaAccount || jumlah === undefined || jumlah === null) {
    return res.status(400).json({ error: 'Data tidak lengkap' });
  }
  const entry = {
    id: crypto.randomUUID(),
    tanggal: String(tanggal),
    penyetor: String(penyetor).trim().toUpperCase(),
    namaAccount: String(namaAccount).trim().toUpperCase(),
    jumlah: Number(jumlah) || 0,
    keterangan: String(keterangan || '').trim(),
    createdAt: Date.now(),
  };
  db.prepare(
    'INSERT INTO entries (id, tanggal, penyetor, namaAccount, jumlah, keterangan, createdAt) VALUES (@id, @tanggal, @penyetor, @namaAccount, @jumlah, @keterangan, @createdAt)'
  ).run(entry);
  res.status(201).json(entry);
});

app.put('/api/entries/:id', (req, res) => {
  const { tanggal, penyetor, namaAccount, jumlah, keterangan } = req.body || {};
  if (!tanggal || !penyetor || !namaAccount || jumlah === undefined || jumlah === null) {
    return res.status(400).json({ error: 'Data tidak lengkap' });
  }
  const result = db.prepare(
    'UPDATE entries SET tanggal=@tanggal, penyetor=@penyetor, namaAccount=@namaAccount, jumlah=@jumlah, keterangan=@keterangan WHERE id=@id'
  ).run({
    id: req.params.id,
    tanggal: String(tanggal),
    penyetor: String(penyetor).trim().toUpperCase(),
    namaAccount: String(namaAccount).trim().toUpperCase(),
    jumlah: Number(jumlah) || 0,
    keterangan: String(keterangan || '').trim(),
  });
  if (result.changes === 0) return res.status(404).json({ error: 'Transaksi tidak ditemukan' });
  res.json({ ok: true });
});

app.delete('/api/entries/:id', (req, res) => {
  db.prepare('DELETE FROM entries WHERE id = ?').run(req.params.id);
  res.json({ ok: true });
});

// ---- Categories ----
app.get('/api/categories', (req, res) => {
  const rows = db.prepare('SELECT name FROM categories ORDER BY name ASC').all();
  res.json(rows.map((r) => r.name));
});

app.post('/api/categories', (req, res) => {
  const name = String((req.body || {}).name || '').trim().toUpperCase();
  if (!name) return res.status(400).json({ error: 'Nama kategori kosong' });
  try {
    db.prepare('INSERT INTO categories (name) VALUES (?)').run(name);
  } catch (e) {
    return res.status(409).json({ error: 'Kategori sudah ada' });
  }
  res.status(201).json({ name });
});

app.delete('/api/categories/:name', (req, res) => {
  db.prepare('DELETE FROM categories WHERE name = ?').run(req.params.name);
  res.json({ ok: true });
});

// ---- Serve built frontend (client/dist) ----
const clientDist = path.join(__dirname, '..', 'client', 'dist');
app.use(express.static(clientDist));
app.get('*', (req, res) => {
  res.sendFile(path.join(clientDist, 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Buku Kas Lapangan server berjalan di port ${PORT}`);
});
