import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import * as XLSX from 'xlsx';
import _ from 'lodash';
import {
  Plus, Trash2, Pencil, Check, X, FileSpreadsheet, Printer,
  RefreshCw, Search, ChevronDown, AlertCircle, Loader2, Settings2
} from 'lucide-react';

const BULAN = ['Jan','Feb','Mar','Apr','Mei','Jun','Jul','Agu','Sep','Okt','Nov','Des'];
const BULAN_PANJANG = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];

const AKUN_UMUM = ['TOL', 'PARKIR', 'PARKIR LIAR', 'BONGKAR MUAT'];

function todayISO() {
  const d = new Date();
  return d.toISOString().slice(0, 10);
}

function fmtDateShort(iso) {
  if (!iso) return '';
  const [y, m, d] = iso.split('-').map(Number);
  if (!y) return iso;
  return `${String(d).padStart(2, '0')} ${BULAN[m - 1]}`;
}

function fmtDateFull(iso) {
  if (!iso) return '';
  const [y, m, d] = iso.split('-').map(Number);
  if (!y) return iso;
  return `${String(d).padStart(2, '0')} ${BULAN_PANJANG[m - 1]} ${y}`;
}

function fmtRupiah(n) {
  const num = Number(n) || 0;
  return 'Rp ' + num.toLocaleString('id-ID');
}

function sanitizeFilename(s) {
  return s.replace(/[^a-z0-9\-]+/gi, '_');
}

export default function FieldLedgerApp() {
  const [entries, setEntries] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [loadError, setLoadError] = useState(false);
  const [version, setVersion] = useState(0);

  const [categories, setCategories] = useState(AKUN_UMUM);
  const [showCatManager, setShowCatManager] = useState(false);
  const [newCatInput, setNewCatInput] = useState('');
  const [catError, setCatError] = useState('');

  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({
    tanggal: todayISO(), penyetor: '', namaAccount: '', jumlah: '', keterangan: '',
  });
  const [formError, setFormError] = useState('');
  const namaAccountRef = useRef(null);

  const [editingId, setEditingId] = useState(null);
  const [editForm, setEditForm] = useState(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState(null);

  const [search, setSearch] = useState('');
  const [filterMode, setFilterMode] = useState('all'); // all | range | month | year
  const now = new Date();
  const [rangeFrom, setRangeFrom] = useState('');
  const [rangeTo, setRangeTo] = useState('');
  const [selMonth, setSelMonth] = useState(now.getMonth() + 1);
  const [selYear, setSelYear] = useState(now.getFullYear());

  const printRef = useRef(null);

  const loadEntries = useCallback(async () => {
    setLoading(true);
    setLoadError(false);
    try {
      const res = await fetch('/api/entries');
      if (!res.ok) throw new Error('bad response');
      const data = await res.json();
      setEntries(Array.isArray(data) ? data : []);
    } catch (e) {
      setLoadError(true);
    } finally {
      setLoading(false);
    }
  }, []);

  const loadCategories = useCallback(async () => {
    try {
      const res = await fetch('/api/categories');
      if (!res.ok) throw new Error('bad response');
      const data = await res.json();
      setCategories(Array.isArray(data) && data.length ? data : AKUN_UMUM);
    } catch (e) {
      setCategories(AKUN_UMUM);
    }
  }, []);

  useEffect(() => { loadEntries(); loadCategories(); }, [loadEntries, loadCategories]);

  const addCategory = async () => {
    const name = newCatInput.trim().toUpperCase();
    if (!name) return;
    if (categories.includes(name)) {
      setCatError('Kategori itu sudah ada.');
      return;
    }
    setCatError('');
    try {
      const res = await fetch('/api/categories', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name }),
      });
      if (!res.ok) throw new Error('gagal');
      setCategories((c) => [...c, name]);
      setNewCatInput('');
    } catch (e) {
      setCatError('Gagal menyimpan kategori, coba lagi.');
    }
  };

  const removeCategory = async (name) => {
    try {
      await fetch(`/api/categories/${encodeURIComponent(name)}`, { method: 'DELETE' });
      setCategories((c) => c.filter((x) => x !== name));
    } catch (e) {
      setCatError('Gagal menghapus kategori, coba lagi.');
    }
  };

  const resetForm = () => setForm({ tanggal: todayISO(), penyetor: '', namaAccount: '', jumlah: '', keterangan: '' });
  const resetQuickFields = () => setForm((f) => ({ ...f, namaAccount: '', jumlah: '', keterangan: '' }));

  const handleAdd = async (e) => {
    e.preventDefault();
    if (!form.tanggal || !form.penyetor.trim() || !form.namaAccount.trim() || !form.jumlah) {
      setFormError('Tanggal, penyetor, nama akun, dan jumlah wajib diisi.');
      return;
    }
    setFormError('');
    setSaving(true);
    try {
      const res = await fetch('/api/entries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tanggal: form.tanggal,
          penyetor: form.penyetor.trim(),
          namaAccount: form.namaAccount.trim(),
          jumlah: Number(form.jumlah) || 0,
          keterangan: form.keterangan.trim(),
        }),
      });
      if (!res.ok) throw new Error('gagal simpan');
      const created = await res.json();
      setEntries((prev) => [...prev, created]);
      // Tanggal & Penyetor sering sama untuk banyak transaksi berturut-turut,
      // jadi hanya kolom transaksi yang direset, dan fokus balik ke Nama Account.
      resetQuickFields();
      setTimeout(() => namaAccountRef.current?.focus(), 0);
    } catch (e) {
      setFormError('Gagal menyimpan ke server, coba lagi.');
    } finally {
      setSaving(false);
    }
  };

  const startEdit = (entry) => {
    setEditingId(entry.id);
    setEditForm({ ...entry, jumlah: String(entry.jumlah) });
    setConfirmDeleteId(null);
  };

  const cancelEdit = () => { setEditingId(null); setEditForm(null); };

  const saveEdit = async () => {
    if (!editForm.tanggal || !editForm.penyetor.trim() || !editForm.namaAccount.trim() || !editForm.jumlah) return;
    setSaving(true);
    const payload = {
      tanggal: editForm.tanggal,
      penyetor: editForm.penyetor.trim(),
      namaAccount: editForm.namaAccount.trim(),
      jumlah: Number(editForm.jumlah) || 0,
      keterangan: editForm.keterangan.trim(),
    };
    try {
      const res = await fetch(`/api/entries/${editingId}`, {
        method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload),
      });
      if (!res.ok) throw new Error('gagal update');
      setEntries((prev) => prev.map((en) => en.id === editingId ? { ...en, ...payload, penyetor: payload.penyetor.toUpperCase(), namaAccount: payload.namaAccount.toUpperCase() } : en));
      cancelEdit();
    } catch (e) {
      setLoadError(true);
    } finally {
      setSaving(false);
    }
  };

  const doDelete = async (id) => {
    setSaving(true);
    try {
      const res = await fetch(`/api/entries/${id}`, { method: 'DELETE' });
      if (!res.ok) throw new Error('gagal hapus');
      setEntries((prev) => prev.filter((en) => en.id !== id));
    } catch (e) {
      setLoadError(true);
    } finally {
      setSaving(false);
      setConfirmDeleteId(null);
    }
  };

  const years = useMemo(() => {
    const set = new Set(entries.map((e) => Number(e.tanggal?.slice(0, 4))).filter(Boolean));
    set.add(now.getFullYear());
    return Array.from(set).sort((a, b) => b - a);
  }, [entries]);

  const filtered = useMemo(() => {
    let list = entries;
    if (filterMode === 'range' && rangeFrom && rangeTo) {
      list = list.filter((e) => e.tanggal >= rangeFrom && e.tanggal <= rangeTo);
    } else if (filterMode === 'month') {
      const mm = String(selMonth).padStart(2, '0');
      list = list.filter((e) => e.tanggal?.slice(0, 7) === `${selYear}-${mm}`);
    } else if (filterMode === 'year') {
      list = list.filter((e) => e.tanggal?.slice(0, 4) === String(selYear));
    }
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      list = list.filter((e) =>
        e.penyetor.toLowerCase().includes(q) ||
        e.namaAccount.toLowerCase().includes(q) ||
        e.keterangan.toLowerCase().includes(q)
      );
    }
    return [...list].sort((a, b) => (a.tanggal + a.createdAt).localeCompare(b.tanggal + b.createdAt));
  }, [entries, filterMode, rangeFrom, rangeTo, selMonth, selYear, search]);

  const total = useMemo(() => filtered.reduce((s, e) => s + (Number(e.jumlah) || 0), 0), [filtered]);

  const byAccount = useMemo(() => {
    const grouped = _.groupBy(filtered, 'namaAccount');
    return Object.entries(grouped)
      .map(([name, rows]) => ({ name, total: rows.reduce((s, r) => s + (Number(r.jumlah) || 0), 0), count: rows.length }))
      .sort((a, b) => b.total - a.total);
  }, [filtered]);

  const periodLabel = () => {
    if (filterMode === 'month') return `${BULAN_PANJANG[selMonth - 1]} ${selYear}`;
    if (filterMode === 'year') return `Tahun ${selYear}`;
    if (filterMode === 'range' && rangeFrom && rangeTo) return `${fmtDateFull(rangeFrom)} — ${fmtDateFull(rangeTo)}`;
    return 'Semua Transaksi';
  };

  const exportExcel = () => {
    const rows = filtered.map((e) => ([
      fmtDateShort(e.tanggal), e.penyetor, e.namaAccount, e.jumlah, e.keterangan,
    ]));
    const wsData = [
      ['Tanggal', 'Penyetor', 'Nama Account', 'Jumlah', 'Keterangan'],
      ...rows,
      [],
      ['Total', '', '', total, ''],
    ];
    const ws = XLSX.utils.aoa_to_sheet(wsData);
    ws['!cols'] = [{ wch: 10 }, { wch: 12 }, { wch: 16 }, { wch: 12 }, { wch: 55 }];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Laporan');
    XLSX.writeFile(wb, `laporan_kas_${sanitizeFilename(periodLabel())}.xlsx`);
  };

  const exportPDF = () => {
    window.print();
  };

  return (
    <div className="lf-root">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Inter:wght@400;500;600&family=IBM+Plex+Mono:wght@400;500;600;700&display=swap');

        .lf-root {
          --ink: #12261B;
          --ink-soft: #3C5245;
          --paper: #EEF1E7;
          --paper-card: #FBFBF6;
          --line: #C7CFC0;
          --green-deep: #163826;
          --green-mid: #1F4A32;
          --amber: #B9822F;
          --amber-soft: #EFE0C3;
          --red: #A6392C;
          font-family: 'Inter', sans-serif;
          color: var(--ink);
          background: var(--paper);
          min-height: 100%;
          padding-bottom: 96px;
        }
        .lf-mono { font-family: 'IBM Plex Mono', monospace; }
        .lf-display { font-family: 'Space Grotesk', sans-serif; }

        .lf-header {
          background: var(--green-deep);
          color: #EFEEE2;
          padding: 20px 20px 22px;
          position: relative;
          overflow: hidden;
        }
        .lf-header::after {
          content: '';
          position: absolute; inset: 0;
          background-image: repeating-linear-gradient(90deg, rgba(255,255,255,0.035) 0 1px, transparent 1px 26px);
          pointer-events: none;
        }
        .lf-eyebrow {
          font-family: 'IBM Plex Mono', monospace;
          font-size: 11px;
          letter-spacing: 0.14em;
          text-transform: uppercase;
          color: #9FBBA8;
        }
        .lf-title {
          font-size: 24px;
          font-weight: 700;
          letter-spacing: -0.01em;
          margin-top: 2px;
        }
        .lf-sub {
          font-size: 12.5px;
          color: #B9CCBE;
          margin-top: 4px;
        }
        .lf-sync {
          font-size: 11px;
          font-family: 'IBM Plex Mono', monospace;
          color: #9FBBA8;
          display: inline-flex;
          align-items: center;
          gap: 5px;
          margin-top: 10px;
        }

        .lf-body { max-width: 980px; margin: 0 auto; padding: 16px 16px 0; }

        .lf-card {
          background: var(--paper-card);
          border: 1px solid var(--line);
          border-radius: 10px;
        }

        .lf-filterbar { padding: 12px 14px; margin-bottom: 14px; }
        .lf-chips { display: flex; flex-wrap: wrap; gap: 6px; }
        .lf-chip {
          font-family: 'IBM Plex Mono', monospace;
          font-size: 11.5px;
          padding: 6px 11px;
          border-radius: 999px;
          border: 1px solid var(--line);
          background: transparent;
          color: var(--ink-soft);
          cursor: pointer;
          white-space: nowrap;
        }
        .lf-chip.active { background: var(--green-deep); color: #EFEEE2; border-color: var(--green-deep); }
        .lf-subfilter { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 10px; align-items: center; }
        .lf-input, .lf-select {
          font-family: 'Inter', sans-serif;
          font-size: 13px;
          padding: 6px 9px;
          border-radius: 6px;
          border: 1px solid var(--line);
          background: #fff;
          color: var(--ink);
        }
        .lf-searchwrap { position: relative; margin-left: auto; }
        .lf-searchwrap input { padding-left: 28px; width: 190px; }
        .lf-searchwrap svg { position: absolute; left: 8px; top: 50%; transform: translateY(-50%); opacity: 0.5; }

        .lf-summary { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 14px; }
        .lf-summary-item {
          font-family: 'IBM Plex Mono', monospace;
          font-size: 12px;
          padding: 8px 12px;
          background: var(--amber-soft);
          border-radius: 8px;
          color: #6B4E1E;
          border: 1px solid #E0CDA0;
        }
        .lf-summary-item b { font-size: 13px; }

        .lf-addtoggle {
          display: flex; align-items: center; gap: 8px;
          padding: 12px 14px;
          cursor: pointer;
          font-family: 'Space Grotesk', sans-serif;
          font-weight: 600;
          font-size: 14px;
          color: var(--green-deep);
        }
        .lf-addform { padding: 4px 14px 16px; display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
        .lf-addform .full { grid-column: 1 / -1; }
        .lf-formheader {
          background: var(--amber-soft);
          border: 1px dashed #D3B679;
          border-radius: 8px;
          padding: 10px 12px 12px;
          margin-bottom: 2px;
        }
        .lf-formheader-label {
          font-size: 10.5px;
          font-family: 'IBM Plex Mono', monospace;
          text-transform: uppercase;
          letter-spacing: 0.05em;
          color: #6B4E1E;
          margin-bottom: 8px;
        }
        .lf-formheader-fields { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; }
        @media (max-width: 640px) { .lf-formheader-fields { grid-template-columns: 1fr; } }
        .lf-field label { font-size: 11px; color: var(--ink-soft); display: flex; align-items: center; gap: 6px; margin-bottom: 4px; font-weight: 500; }
        .lf-catmanage-btn {
          margin-left: auto;
          display: inline-flex; align-items: center; gap: 3px;
          font-size: 10.5px; font-family: 'IBM Plex Mono', monospace;
          background: none; border: none; color: var(--amber); cursor: pointer;
          padding: 0;
        }
        .lf-catmanage-btn:hover { text-decoration: underline; }
        .lf-catmanager {
          margin-top: 8px; padding: 10px; border: 1px solid var(--line); border-radius: 7px; background: #fff;
        }
        .lf-catchips { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 8px; }
        .lf-catchip {
          display: inline-flex; align-items: center; gap: 5px;
          font-size: 11px; font-family: 'IBM Plex Mono', monospace;
          background: #E4E9DC; color: var(--green-deep); padding: 3px 4px 3px 9px; border-radius: 999px;
        }
        .lf-catchip button { background: none; border: none; cursor: pointer; color: var(--ink-soft); display: flex; padding: 2px; border-radius: 50%; }
        .lf-catchip button:hover { background: #d3dcc6; color: var(--red); }
        .lf-catadd { display: flex; gap: 6px; }
        .lf-catadd input { flex: 1; font-size: 12.5px; padding: 5px 8px; border: 1px solid var(--line); border-radius: 6px; }
        .lf-field input, .lf-field textarea, .lf-field select { width: 100%; box-sizing: border-box; }
        .lf-formerr { grid-column: 1/-1; color: var(--red); font-size: 12px; display: flex; gap: 5px; align-items: center; }
        .lf-btn {
          font-family: 'Space Grotesk', sans-serif;
          font-weight: 600;
          font-size: 13px;
          padding: 8px 16px;
          border-radius: 7px;
          border: none;
          cursor: pointer;
          display: inline-flex;
          align-items: center;
          gap: 6px;
        }
        .lf-btn-primary { background: var(--green-deep); color: #EFEEE2; }
        .lf-btn-primary:hover { background: var(--green-mid); }
        .lf-btn-ghost { background: transparent; color: var(--ink-soft); border: 1px solid var(--line); }

        .lf-tablewrap { overflow-x: auto; margin-bottom: 14px; }
        table.lf-table { width: 100%; border-collapse: collapse; min-width: 720px; }
        .lf-table thead th {
          text-align: left;
          font-family: 'IBM Plex Mono', monospace;
          font-size: 10.5px;
          letter-spacing: 0.06em;
          text-transform: uppercase;
          color: #F0EEE0;
          background: var(--green-mid);
          padding: 9px 10px;
          position: sticky; top: 0;
        }
        .lf-table thead th:first-child { border-top-left-radius: 10px; }
        .lf-table thead th:last-child { border-top-right-radius: 10px; }
        .lf-table td { padding: 8px 10px; border-bottom: 1px solid var(--line); font-size: 13px; vertical-align: top; }
        .lf-table tbody tr:hover { background: #F3F5EC; }
        .lf-jumlah { font-family: 'IBM Plex Mono', monospace; font-weight: 600; white-space: nowrap; }
        .lf-tgl { font-family: 'IBM Plex Mono', monospace; white-space: nowrap; color: var(--ink-soft); }
        .lf-akun-badge {
          display: inline-block; font-size: 11px; padding: 2px 8px; border-radius: 5px;
          background: #E4E9DC; color: var(--green-deep); font-weight: 600;
        }
        .lf-rowactions { display: flex; gap: 4px; white-space: nowrap; }
        .lf-iconbtn { background: none; border: none; cursor: pointer; padding: 4px; border-radius: 5px; color: var(--ink-soft); }
        .lf-iconbtn:hover { background: #E4E9DC; }
        .lf-iconbtn.danger:hover { background: #F3DEDA; color: var(--red); }
        .lf-empty { text-align: center; padding: 36px 14px; color: var(--ink-soft); font-size: 13px; }
        .lf-editrow input { font-size: 12.5px; padding: 4px 6px; width: 100%; box-sizing: border-box; border: 1px solid var(--line); border-radius: 5px; }

        .lf-confirmdel { display: flex; gap: 6px; align-items: center; font-size: 12px; }

        .lf-footer {
          position: fixed; bottom: 0; left: 0; right: 0;
          background: var(--green-deep);
          color: #EFEEE2;
          padding: 12px 18px;
          display: flex; align-items: center; gap: 16px; flex-wrap: wrap;
          box-shadow: 0 -6px 18px rgba(0,0,0,0.18);
          --notch: 12px;
          mask-image: radial-gradient(circle at 0 0, transparent 0, transparent 0), linear-gradient(#000,#000);
        }
        .lf-footer::before {
          content: '';
          position: absolute; top: -1px; left: 0; right: 0; height: 8px;
          background-image: radial-gradient(circle at 8px 0, transparent 7px, var(--paper) 7px);
          background-size: 16px 8px;
          background-repeat: repeat-x;
        }
        .lf-footer-period { font-family: 'IBM Plex Mono', monospace; font-size: 11px; color: #9FBBA8; }
        .lf-footer-total { font-family: 'IBM Plex Mono', monospace; font-size: 22px; font-weight: 700; letter-spacing: -0.02em; }
        .lf-footer-actions { margin-left: auto; display: flex; gap: 8px; }
        .lf-btn-footer { background: rgba(255,255,255,0.1); color: #EFEEE2; }
        .lf-btn-footer:hover { background: rgba(255,255,255,0.18); }

        .lf-loading { display: flex; align-items: center; justify-content: center; padding: 60px; gap: 8px; color: var(--ink-soft); }
        .lf-spin { animation: lf-spin 1s linear infinite; }
        @keyframes lf-spin { to { transform: rotate(360deg); } }

        .lf-print-area { display: none; }
        @media print {
          .lf-root > *:not(.lf-print-area) { display: none !important; }
          .lf-print-area { display: block !important; font-family: 'Inter', sans-serif; padding: 20px; }
          .lf-print-area table { width: 100%; border-collapse: collapse; }
          .lf-print-area th, .lf-print-area td { border: 1px solid #999; padding: 6px 8px; font-size: 12px; text-align: left; }
          .lf-print-area th { background: #163826 !important; color: #fff !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
          .lf-print-area .p-jumlah { text-align: right; font-family: 'IBM Plex Mono', monospace; }
          .lf-print-area h1 { font-size: 16px; margin: 0 0 2px; }
          .lf-print-area .p-sub { font-size: 11px; color: #555; margin-bottom: 14px; }
          .lf-print-area tfoot td { font-weight: 700; background: #EFE0C3 !important; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        }

        @media (max-width: 640px) {
          .lf-addform { grid-template-columns: 1fr; }
          .lf-searchwrap { margin-left: 0; }
          .lf-searchwrap input { width: 100%; }
        }
      `}</style>

      <div className="lf-header">
        <div className="lf-eyebrow">Catatan Operasional</div>
        <div className="lf-title lf-display">Buku Kas Lapangan</div>
        <div className="lf-sub">Tol · Parkir · Bongkar Muat — dicatat tim, tersimpan di server</div>
        <div className="lf-sync">
          {saving ? (<><Loader2 size={12} className="lf-spin" /> Menyimpan…</>) : loadError ? (<><AlertCircle size={12} /> Gagal terhubung ke server — coba muat ulang</>) : (<>● Tersambung ke server — dilihat semua anggota tim</>)}
        </div>
      </div>

      <div className="lf-body">
        {loading ? (
          <div className="lf-loading"><Loader2 size={18} className="lf-spin" /> Memuat data…</div>
        ) : (
          <>
            <div className="lf-card lf-filterbar">
              <div className="lf-chips">
                <button className={`lf-chip ${filterMode === 'all' ? 'active' : ''}`} onClick={() => setFilterMode('all')}>Semua</button>
                <button className={`lf-chip ${filterMode === 'range' ? 'active' : ''}`} onClick={() => setFilterMode('range')}>Rentang Tanggal</button>
                <button className={`lf-chip ${filterMode === 'month' ? 'active' : ''}`} onClick={() => setFilterMode('month')}>Per Bulan</button>
                <button className={`lf-chip ${filterMode === 'year' ? 'active' : ''}`} onClick={() => setFilterMode('year')}>Per Tahun</button>
                <button className="lf-chip" onClick={loadEntries} title="Muat ulang data"><RefreshCw size={11} style={{ verticalAlign: -1 }} /></button>
                <div className="lf-searchwrap">
                  <Search size={13} />
                  <input className="lf-input" placeholder="Cari penyetor / akun / keterangan" value={search} onChange={(e) => setSearch(e.target.value)} />
                </div>
              </div>
              {(filterMode === 'range' || filterMode === 'month' || filterMode === 'year') && (
                <div className="lf-subfilter">
                  {filterMode === 'range' && (
                    <>
                      <label style={{ fontSize: 12, color: 'var(--ink-soft)' }}>Dari</label>
                      <input type="date" className="lf-input" value={rangeFrom} onChange={(e) => setRangeFrom(e.target.value)} />
                      <label style={{ fontSize: 12, color: 'var(--ink-soft)' }}>Sampai</label>
                      <input type="date" className="lf-input" value={rangeTo} onChange={(e) => setRangeTo(e.target.value)} />
                    </>
                  )}
                  {filterMode === 'month' && (
                    <>
                      <select className="lf-select" value={selMonth} onChange={(e) => setSelMonth(Number(e.target.value))}>
                        {BULAN_PANJANG.map((b, i) => <option key={b} value={i + 1}>{b}</option>)}
                      </select>
                      <select className="lf-select" value={selYear} onChange={(e) => setSelYear(Number(e.target.value))}>
                        {years.map((y) => <option key={y} value={y}>{y}</option>)}
                      </select>
                    </>
                  )}
                  {filterMode === 'year' && (
                    <select className="lf-select" value={selYear} onChange={(e) => setSelYear(Number(e.target.value))}>
                      {years.map((y) => <option key={y} value={y}>{y}</option>)}
                    </select>
                  )}
                </div>
              )}
            </div>

            {byAccount.length > 0 && (
              <div className="lf-summary">
                {byAccount.map((a) => (
                  <div key={a.name} className="lf-summary-item">{a.name}: <b>{fmtRupiah(a.total)}</b> <span style={{ opacity: 0.65 }}>({a.count}x)</span></div>
                ))}
              </div>
            )}

            <div className="lf-card" style={{ marginBottom: 14 }}>
              <div className="lf-addtoggle" onClick={() => setShowForm((s) => !s)}>
                <Plus size={16} /> Tambah Transaksi
                <ChevronDown size={15} style={{ marginLeft: 'auto', transform: showForm ? 'rotate(180deg)' : 'none', transition: 'transform .15s' }} />
              </div>
              {showForm && (
                <form className="lf-addform" onSubmit={handleAdd}>
                  <div className="lf-formheader full">
                    <div className="lf-formheader-label">Berlaku untuk transaksi berikutnya juga</div>
                    <div className="lf-formheader-fields">
                      <div className="lf-field">
                        <label>Tanggal</label>
                        <input type="date" value={form.tanggal} onChange={(e) => setForm({ ...form, tanggal: e.target.value })} className="lf-input" />
                      </div>
                      <div className="lf-field">
                        <label>Penyetor</label>
                        <input type="text" placeholder="mis. RIAN" value={form.penyetor} onChange={(e) => setForm({ ...form, penyetor: e.target.value })} className="lf-input" />
                      </div>
                    </div>
                  </div>
                  <div className="lf-field">
                    <label>
                      Nama Account
                      <button type="button" className="lf-catmanage-btn" onClick={() => setShowCatManager((s) => !s)}>
                        <Settings2 size={11} /> Kelola
                      </button>
                    </label>
                    <select ref={namaAccountRef} value={form.namaAccount} onChange={(e) => setForm({ ...form, namaAccount: e.target.value })} className="lf-input">
                      <option value="">-- pilih akun --</option>
                      {categories.map((c) => <option key={c} value={c}>{c}</option>)}
                    </select>
                    {showCatManager && (
                      <div className="lf-catmanager">
                        <div className="lf-catchips">
                          {categories.map((c) => (
                            <span key={c} className="lf-catchip">{c}<button type="button" onClick={() => removeCategory(c)}><X size={11} /></button></span>
                          ))}
                          {categories.length === 0 && <span style={{ fontSize: 11, color: 'var(--ink-soft)' }}>Belum ada kategori.</span>}
                        </div>
                        <div className="lf-catadd">
                          <input type="text" placeholder="Kategori baru, mis. BBM" value={newCatInput}
                            onChange={(e) => setNewCatInput(e.target.value)}
                            onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addCategory(); } }} />
                          <button type="button" className="lf-btn lf-btn-ghost" onClick={addCategory}><Plus size={12} /></button>
                        </div>
                        {catError && <div className="lf-formerr"><AlertCircle size={12} /> {catError}</div>}
                      </div>
                    )}
                  </div>
                  <div className="lf-field">
                    <label>Jumlah (Rp)</label>
                    <input type="number" min="0" placeholder="0" value={form.jumlah} onChange={(e) => setForm({ ...form, jumlah: e.target.value })} className="lf-input" />
                  </div>
                  <div className="lf-field full">
                    <label>Keterangan</label>
                    <input type="text" placeholder="mis. F 8301 MB, PARKIR PS. CISARUA" value={form.keterangan} onChange={(e) => setForm({ ...form, keterangan: e.target.value })} className="lf-input" />
                  </div>
                  {formError && <div className="lf-formerr"><AlertCircle size={13} /> {formError}</div>}
                  <div className="full" style={{ display: 'flex', gap: 8 }}>
                    <button type="submit" className="lf-btn lf-btn-primary"><Plus size={14} /> Simpan & Lanjut Transaksi Berikutnya</button>
                    <button type="button" className="lf-btn lf-btn-ghost" onClick={() => { resetForm(); setShowForm(false); }}>Selesai / Tutup</button>
                  </div>
                </form>
              )}
            </div>

            <div className="lf-card lf-tablewrap">
              <table className="lf-table">
                <thead>
                  <tr>
                    <th>Tanggal</th><th>Penyetor</th><th>Nama Account</th><th style={{ textAlign: 'right' }}>Jumlah</th><th>Keterangan</th><th></th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.length === 0 && (
                    <tr><td colSpan={6} className="lf-empty">Belum ada transaksi untuk periode ini. Tambahkan transaksi pertama di atas.</td></tr>
                  )}
                  {filtered.map((e) => (
                    editingId === e.id ? (
                      <tr key={e.id} className="lf-editrow">
                        <td><input type="date" value={editForm.tanggal} onChange={(ev) => setEditForm({ ...editForm, tanggal: ev.target.value })} /></td>
                        <td><input type="text" value={editForm.penyetor} onChange={(ev) => setEditForm({ ...editForm, penyetor: ev.target.value })} /></td>
                        <td><select value={editForm.namaAccount} onChange={(ev) => setEditForm({ ...editForm, namaAccount: ev.target.value })}>
                          <option value={editForm.namaAccount}>{editForm.namaAccount}</option>
                          {categories.filter((c) => c !== editForm.namaAccount).map((c) => <option key={c} value={c}>{c}</option>)}
                        </select></td>
                        <td><input type="number" value={editForm.jumlah} onChange={(ev) => setEditForm({ ...editForm, jumlah: ev.target.value })} /></td>
                        <td><input type="text" value={editForm.keterangan} onChange={(ev) => setEditForm({ ...editForm, keterangan: ev.target.value })} /></td>
                        <td>
                          <div className="lf-rowactions">
                            <button className="lf-iconbtn" onClick={saveEdit} title="Simpan"><Check size={15} /></button>
                            <button className="lf-iconbtn" onClick={cancelEdit} title="Batal"><X size={15} /></button>
                          </div>
                        </td>
                      </tr>
                    ) : (
                      <tr key={e.id}>
                        <td className="lf-tgl">{fmtDateShort(e.tanggal)}</td>
                        <td>{e.penyetor}</td>
                        <td><span className="lf-akun-badge">{e.namaAccount}</span></td>
                        <td className="lf-jumlah" style={{ textAlign: 'right' }}>{fmtRupiah(e.jumlah)}</td>
                        <td>{e.keterangan}</td>
                        <td>
                          {confirmDeleteId === e.id ? (
                            <div className="lf-confirmdel">
                              <span>Hapus?</span>
                              <button className="lf-iconbtn danger" onClick={() => doDelete(e.id)}><Check size={14} /></button>
                              <button className="lf-iconbtn" onClick={() => setConfirmDeleteId(null)}><X size={14} /></button>
                            </div>
                          ) : (
                            <div className="lf-rowactions">
                              <button className="lf-iconbtn" onClick={() => startEdit(e)} title="Ubah"><Pencil size={14} /></button>
                              <button className="lf-iconbtn danger" onClick={() => setConfirmDeleteId(e.id)} title="Hapus"><Trash2 size={14} /></button>
                            </div>
                          )}
                        </td>
                      </tr>
                    )
                  ))}
                </tbody>
              </table>
            </div>
          </>
        )}
      </div>

      <div className="lf-footer">
        <div>
          <div className="lf-footer-period">{periodLabel()} · {filtered.length} transaksi</div>
          <div className="lf-footer-total">{fmtRupiah(total)}</div>
        </div>
        <div className="lf-footer-actions">
          <button className="lf-btn lf-btn-footer" onClick={exportExcel}><FileSpreadsheet size={14} /> Excel</button>
          <button className="lf-btn lf-btn-footer" onClick={exportPDF}><Printer size={14} /> PDF</button>
        </div>
      </div>

      <div className="lf-print-area" ref={printRef}>
        <h1>Laporan Kas Lapangan</h1>
        <div className="p-sub">Periode: {periodLabel()} · Dicetak {fmtDateFull(todayISO())}</div>
        <table>
          <thead>
            <tr><th>Tanggal</th><th>Penyetor</th><th>Nama Account</th><th>Jumlah</th><th>Keterangan</th></tr>
          </thead>
          <tbody>
            {filtered.map((e) => (
              <tr key={e.id}>
                <td>{fmtDateShort(e.tanggal)}</td>
                <td>{e.penyetor}</td>
                <td>{e.namaAccount}</td>
                <td className="p-jumlah">{fmtRupiah(e.jumlah)}</td>
                <td>{e.keterangan}</td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr><td colSpan={3}>Total</td><td className="p-jumlah">{fmtRupiah(total)}</td><td></td></tr>
          </tfoot>
        </table>
      </div>
    </div>
  );
}
